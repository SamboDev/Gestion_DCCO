<?php

namespace App\Filament\Resources\AreaConocimientoResource\Pages;

use App\Filament\Resources\AreaConocimientoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAreaConocimiento extends CreateRecord
{
    protected static string $resource = AreaConocimientoResource::class;
}
