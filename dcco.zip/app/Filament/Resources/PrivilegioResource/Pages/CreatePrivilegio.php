<?php

namespace App\Filament\Resources\PrivilegioResource\Pages;

use App\Filament\Resources\PrivilegioResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePrivilegio extends CreateRecord
{
    protected static string $resource = PrivilegioResource::class;
}
